# ---
# jupyter:
#   jupytext:
#     custom_cell_magics: kql
#     text_representation:
#       extension: .py
#       format_name: percent
#   kernelspec:
#     display_name: Python 3 (ipykernel)
#     language: python
#     name: python3
#   language_info:
#     name: python
#     nbconvert_exporter: python
#     pygments_lexer: ipython3
# ---

# %% [markdown]
# # grouping through time and category
#
# to work on this assignment locally on your laptop, {download}`start with downloading the zip<./ARTEFACTS-leases.zip>`

# %% [markdown]
# ## imports

# %%
import pandas as pd
import matplotlib.pyplot as plt


# %% [markdown]
# 1. make sure to use matplotlib in interactive mode - aka `ipympl`

# %%
# your code

# %% [markdown]
# ## the data
#
# we have a table of events, each with a begin and end time; in addition each is attached to a country

# %%
leases = pd.read_csv("data/leases.csv")
leases.head(4)

# %% [markdown]
# adapt the type of each columns

# %%
# your code

# %%
# check it

leases.dtypes


# %% [markdown]
# ### raincheck
#
# check that the data is well-formed, i.e. the `end` timestamp happens **after** the `beg`inning

# %%
# your code

# %% [markdown]
# ### are there any overlapping events ?

# %% [markdown]
#    it turns out there are no event overlap, but write a code that checks that this is true
#
#    ```{admonition} note
#    :class: tip
#
#    nothing in the rest depends on this question, so if you find this too hard, you can skip to the next question
#    ```

# %%
# your code

# %% [markdown]
# ### timespan
#
# What is the timespan (earliest and latest events, and duration in-between) involved ?

# %%
# your code

# %% [markdown]
# ### aggregated duration
#
# so, given that there is no overlap, we can assume this corresponds to "reservations" attached to a unique resource (hence the term  *lease*)
#
# write a code that computes the overall reservation time, and the average usage ratio

# %%
# your code

# %% [markdown]
# ## visualize usage by period
#
# grouping by periods: by week, by month or by year, display the usage in hours  
# when ambiguous, use the `beg` column to determine if a lease is in a period or the other

# %%
# your code

# %% [markdown]
# ### utility: convert timedelta to hours
#
# write a function that converts a timedelta into a number of hours - see the test code for the details of what is expected

# %%
# your code

def convert_timedelta_to_hours(timedelta):
    pass

# %%
# test it

# if an hour has started even by one second, it is counted
# seconds, hours
test_cases = ( (0, 0), (1, 1), (3600, 1), (3601, 2), (7199, 2), (7200, 2), (7200, 3))

def test_convert_timedelta_to_hours():
    for seconds, exp in test_cases:
        timedelta = pd.Timedelta(seconds=seconds)
        got = convert_timedelta_to_hours(timedelta)
        print(f"with {timedelta=} we get {got} and expected {exp} -> {got == exp}")

test_convert_timedelta_to_hours()

# %% [markdown]
# --- xxx here

# %% [markdown]
# ## attach region
#
# add a column `region` to the leases table, using the following table

# %%
countries = pd.read_csv("data/countries.csv")
countries.head(3)

# %%
# your code

# %%
# prune-

leases2 = leases.merge(countries, left_on='country', right_on='name')
leases2

# %% [markdown]
# ## group by period of time

# %%
# your code

# %%
# your code

# %%
# your code

# %%
# your code

# %%
# your code
